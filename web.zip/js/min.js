/**
     _      _   _ _    __ _ _
    | |    | | (_) |  / _(_) |
    | | ___| |_ _| |_| |_ _| |_
    | |/ _ \ __| | __|  _| | __|
    | |  __/ |_| | |_| | | | |_
    |_|\___|\__|_|\__|_| |_|\__|

    v1.0 - jQuery plugin created by Alvaro Prieto Lauroba.

    LICENSE:

    - free for personal use in non-profit websites
    - $5 for commercial usages and brands (one single site license)
    - $10 for commercial purpose, you will be able to use it in as many sites as you want (lifetime license)
    - $15 if you want to include it in a redistributable package, such as website templates, mobile apps, etc..

    - Any donation is extremely appreciated, I don't earn much money  :-)

*/

for(var q="function"==typeof Object.defineProperties?Object.defineProperty:function(e,w,l){if(l.get||l.set)throw new TypeError("ES3 does not support getters and setters.");e!=Array.prototype&&e!=Object.prototype&&(e[w]=l.value)},t="undefined"!=typeof window&&window===this?this:"undefined"!=typeof global&&null!=global?global:this,x=["Array","prototype","find"],y=0;y<x.length-1;y++){var z=x[y];z in t||(t[z]={});t=t[z]}
var D=x[x.length-1],E=t[D],I=function(e){return e?e:function(e,l){var f;a:{f=this;f instanceof String&&(f=String(f));for(var u=f.length,m=0;m<u;m++){var r=f[m];if(e.call(l,r,m,f)){f=r;break a}}f=void 0}return f}}(E);I!=E&&null!=I&&q(t,D,{configurable:!0,writable:!0,value:I});
(function(e){function w(){if("undefined"==typeof matchMedia)console.warn("MATCHMEDIA ERROR: your browser does not support matchMedia. Use a polyfill for further compatibility");else{var a=null,b="",d,c,n,h;e.each(k,function(p,g){k.hasOwnProperty(p)&&(a=e("[data-fit-"+g+"]"),b="fit-"+g,a.each(function(a,g){g=e(g);d=g.data(b);c=[0,999999];h=n=null;switch(p){case k.s:h=c[1]=1*f(d,c);break;case k.l:h=c[0]=1*f(d,c);break;case k.m:c=r(d);h=c[1];break;case k.o:n=m(d);break;case k.target:h=1*f(d,c);break;
    case k.j:n=u(d,J);break;case k.i:n=u(d,K)}if(null===n)l(g,c,h);else for(a=0;a<n.length;a++)c=n[a],h=999999==c[1]?c[0]:c[1],l(g,c,h)}))});p.length&&(F.prepend('<meta id="meta_letitfit" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />'),e(window).bind("resize._letitfit",G),H(),G())}}function l(a,b,d){var c=g()+"_letitfit",f="BODY"==a.prop("tagName");if("px"!=b.units){var h=parseFloat(L.css("font-size"));d=parseInt(d*h)}b={id:c,global:f,width:d,
active:!1,element:a,bottom:b[0],top:b[1],query:null,style:null,g:null,b:0,units:b.units,f:null,c:null,sensitivity:1,a:"smooth"};b.query=window.matchMedia("(min-width: "+b.bottom+b.units+") and (max-width: "+b.top+b.units+")");if(!b.global){a=b;if(c=a.element.data("fit-sensitivity"))switch(c=e.trim(c.toString().toLowerCase()),c){case "medium":a.sensitivity=2;break;case "high":a.sensitivity=3}M(b)}a=b;if(c=a.element.data("fit-smoothing"))switch(c=e.trim(c.toString().toLowerCase()),c){case "sharp":a.a=
    "sharp";break;case "smooth":a.a="smooth"}else 0===a.bottom&&a.top&&(a.a="sharp");p.push(b);b.query.addListener(H)}function f(a,b){b.units="px";a=a.toString();a=a.replace(/px/g,"");0<=a.indexOf("em")&&(b.units="em",a=a.replace(/em/g,""));return a}function u(a,b){a=a.replace(/\ |\[|\]/g,"").toLowerCase();for(var d=a.split(","),c=[],e,f=0;f<d.length;f++)(e=b[d[f]])&&c.push(e);return m(c.join())}function m(a){var b=[],d;a=a.toString().replace(/(\]\,\[)|(\]\ \[)|(\]\;\[)/g,"][");d=a.split("][");for(var c=
0;c<d.length;c++)a=e.trim(d[c].toString().replace(/\[|\]|\,/g," ")),a=r(a),b.push(a);return b}function r(a){var b=[];a=f(a,b);a=a.replace(/\;|\ |\-/g,",");a=a.split(",");a[1]=0>a[1].toLowerCase().indexOf("inf")?a[1]:999999;a[0]*=1;a[1]*=1;a[0]=2E3<a[0]?999999:a[0];a[1]=2E3<a[1]?999999:a[1];b[0]=Math.min(a[0],a[1]);b[1]=Math.max(a[0],a[1]);return b}function g(){g.h||(g.h=1);return"range_"+g.h++}function M(a){3>a.sensitivity&&a.element.find("img").load(function(){a.active&&(A(a),v(a))});2==a.sensitivity&&
        (a.f=new MutationObserver(function(){a.active&&(A(a),v(a))}));3==a.sensitivity&&(a.c=function(){if(a.active){var b=a.element.height()/a.width;b!=a.b&&(a.b=b,v(a))}requestAnimationFrame(a.c)},a.c())}function G(){var a=1*e(window).width();if(B!=a)for(B=a,a=0;a<C.length;a++)v(C[a])}function v(a){var b,d=e("<div/>"),c="smooth"==a.a?"perspective(1px) ":"";b=B/a.width;d.css("transform",c+"scale("+b+","+b+")").css("transform-origin","0 0 0");d.css("width",a.width).css("position","absolute");a.style.html("."+
a.id+"{"+d.attr("style")+"}");a.global||a.g.css("height",a.b*a.width*b)}function A(a){a.b=a.element.height()/a.width}function H(){var a=[],b,d;for(d=0;d<p.length;d++)b=p[d],b.query.matches?(a.push(b),b.active||(F.append('<style id="'+b.id+'"> </style>'),b.style=e("#"+b.id),b.element.addClass(b.id),b.global||(b.element.wrap("<div/>"),b.g=b.element.parent(),2==b.sensitivity&&b.f.observe(b.element.get(0),{attributes:!0,childList:!0,characterData:!0,subtree:!0})),b.active=!0,A(b))):b.active&&(b.style.remove(),
b.style=null,b.element.removeClass(b.id),b.active=!1,b.global||(b.element.unwrap(),b.g=null,2==b.sensitivity&&b.f.disconnect()));C=a}if(!e)return setTimeout(function(){alert("include jQuery if you want to use Let\u00b7it\u00b7fit")},1E3);var C=[],p=[],B=0,F=e("head"),L=e("body");e(window);var k={s:"under",l:"over",m:"range",o:"ranges",target:"target",a:"smoothing",j:"foundation",i:"bootstrap"},J={small:"[0em,40em]",A:"[40.063em,64em]",u:"[64.063em,inf]"},K={D:"[0,543]",B:"[544,767]",w:"[768,991]",
v:"[992,1199]",C:"[1200,inf]"};e(function(){w()})})("undefined"==typeof jQuery?null:jQuery);
