for (var r = "function" == typeof Object.defineProperties ? Object.defineProperty : function(d, z, q) {
    if (q.get || q.set) throw new TypeError("ES3 does not support getters and setters.");
    d != Array.prototype && d != Object.prototype && (d[z] = q.value)
}, t = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this, A = ["Array", "prototype", "find"], B = 0; B < A.length - 1; B++) {
    var C = A[B];
    C in t || (t[C] = {});
    t = t[C]
}
var F = A[A.length - 1],
    G = t[F],
    K = function(d) {
        return d ? d : function(d, q) {
            var g;
            a: {
                g = this;g instanceof String && (g = String(g));
                for (var u = g.length, l = 0; l < u; l++) {
                    var m = g[l];
                    if (d.call(q, m, l, g)) {
                        g = m;
                        break a
                    }
                }
                g = void 0
            }
            return g
        }
    }(G);
K != G && null != K && r(t, F, {
    configurable: !0,
    writable: !0,
    value: K
});
(function(d) {
    function z() {
        if ("undefined" == typeof matchMedia) console.warn("MATCHMEDIA ERROR: your browser does not support matchMedia. Use a polyfill for further compatibility");
        else {
            var a = null,
                b = "",
                e, c, h, n, k;
            d.each(p, function(m, f) {
                p.hasOwnProperty(m) && (a = d("[data-fit-" + f + "]"), b = "fit-" + f, a.each(function(a, f) {
                    f = d(f);
                    e = f.data(b);
                    c = [0, 999999];
                    n = h = null;
                    switch (m) {
                        case p.A:
                            k = l(e, 1);
                            c[1] = k[0];
                            n = k.target || k[0];
                            break;
                        case p.s:
                            k = l(e, 1);
                            c[0] = k[0];
                            n = k.target || k[0];
                            break;
                        case p.u:
                            k = c = l(e, 2);
                            n = c.target || c[1];
                            break;
                        case p.v:
                            h = u(e);
                            break;
                        case p.target:
                            k = l(e, 1);
                            n = k[0];
                            break;
                        case p.m:
                            h = g(e, L);
                            break;
                        case p.l:
                            h = g(e, M);
                            break;
                        default:
                            return !1
                    }
                    if (null === h) c.units = k.units, q(f, c, n);
                    else
                        for (a = 0; a < h.length; a++) c = h[a], n = c.target ? c.target : 999999 == c[1] ? c[0] : c[1], q(f, c, n)
                            }))
            });
            v.length && (H.prepend('<meta id="meta_letitfit" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />'), d(window).bind("resize._letitfit", I), J(), I())
        }
    }

    function q(a, b, e) {
        var c = m() + "_letitfit",
            h = "BODY" ==
            a.prop("tagName");
        if ("px" != b.units) {
            var n = parseFloat(N.css("font-size"));
            e = parseInt(e * n)
        }
        b = {
            id: c,
            global: h,
            width: e,
            active: !1,
            element: a,
            bottom: b[0],
            top: b[1],
            query: null,
            style: null,
            h: null,
            a: 0,
            units: b.units,
            g: null,
            f: null,
            sensitivity: f.o,
            c: w.j
        };
        b.query = window.matchMedia("(min-width: " + b.bottom + b.units + ") and (max-width: " + b.top + b.units + ")");
        if (!b.global) {
            a = b;
            if (c = a.element.data("fit-sensitivity"))
                if (c = d.trim(c.toString().toLowerCase()), c = f[c]) a.sensitivity = c;
            O(b)
        }
        a = b;
        if (c = a.element.data("fit-smoothing")) {
            if (c =
                d.trim(c.toString().toLowerCase()), c = w[c]) a.c = c
                } else 0 === a.bottom && 999999 == a.top && (a.c = w.w);
        v.push(b);
        b.query.addListener(J)
    }

    function g(a, b) {
        a = a.replace(/\ |\[|\]/g, "").toLowerCase();
        for (var e = a.split(","), c = [], h, d = 0; d < e.length; d++)(h = b[e[d]]) && c.push(h);
        return u(c.join())
    }

    function u(a) {
        var b = [],
            e;
        a = a.toString().replace(/(\]\,\[)|(\]\ \[)|(\]\;\[)/g, "][");
        e = a.split("][");
        for (var c = 0; c < e.length; c++) a = d.trim(e[c].toString().replace(/\[|\]|\,/g, " ")), a = l(a, 2), b.push(a);
        return b
    }

    function l(a, b) {
        var e = [],
            c, d, f;
        e.units = "px";
        c = a.toString().toLowerCase();
        c = c.replace(/px/g, "");
        0 <= c.indexOf("em") && (e.units = "em", c = c.replace(/em/g, ""));
        a = c;
        a = a.replace(/\;|\ |\-/g, ",");
        c = a.split(",");
        f = Math.min(c.length, b + 1);
        for (d = 0; d < f; d++) c[d] = 1 * (0 > c[d].indexOf("inf") ? c[d] : 999999), c[d] = 2E3 < c[d] ? 999999 : c[d], d < b ? e.push(c[d]) : e.target = c[d];
        2 == b && (e[0] = Math.min(c[0], c[1]), e[1] = Math.max(c[0], c[1]));
        return e
    }

    function m() {
        m.i || (m.i = 1);
        return "range_" + m.i++
    }

    function O(a) {
        a.sensitivity < f.high && a.element.find("img").load(function() {
            a.active &&
                (x(a), y(a))
        });
        a.sensitivity == f.b && (a.g = new MutationObserver(function() {
            a.active && (x(a), y(a))
        }));
        a.sensitivity == f.high && (a.f = function() {
            if (a.active) {
                var b = a.element.height() / a.width;
                b != a.a && (a.a = b, y(a))
            }
            requestAnimationFrame(a.f)
        }, a.f())
    }

    function I() {
        var a = 1 * d(window).width();
        if (D != a)
            for (D = a, a = 0; a < E.length; a++) y(E[a])
                }

    function y(a) {
        var b, e = d("<div/>"),
            c = a.c == w.j ? "perspective(1px) " : "";
        b = D / a.width;
        e.css("transform", c + "scale(" + b + "," + b + ")").css("transform-origin", "0 0 0");
        e.css("width", a.width).css({
            position: "absolute",
            overflow: "hidden"
        });
        a.style.html("." + a.id + "{" + e.attr("style") + "}");
        a.global || (x(a), a.h.css("height", a.a * a.width * b))
    }

    function x(a) {
        a.a = a.element.height() / a.width
    }

    function J() {
        var a = [],
            b, e;
        for (e = 0; e < v.length; e++) b = v[e], b.query.matches ? (a.push(b), b.active || (H.append('<style id="' + b.id + '"> </style>'), b.style = d("#" + b.id), b.element.addClass(b.id), b.global || (b.element.wrap("<div/>"), b.h = b.element.parent(), b.sensitivity == f.b && b.g.observe(b.element.get(0), {
            attributes: !0,
            childList: !0,
            characterData: !0,
            subtree: !0
        })),
                                                                                            b.active = !0, x(b))) : b.active && (b.style.remove(), b.style = null, b.element.removeClass(b.id), b.active = !1, b.global || (b.element.unwrap(), b.h = null, b.sensitivity == f.b && b.g.disconnect()));
        E = a
    }
    if (!d) return setTimeout(function() {
        alert("include jQuery if you want to use Let\u00b7it\u00b7fit")
    }, 1E3);
    var E = [],
        v = [],
        D = 0,
        H = d("head"),
        N = d("body");
    d(window);
    var p = {
        A: "under",
        s: "over",
        u: "range",
        v: "ranges",
        target: "target",
        c: "smoothing",
        m: "foundation",
        l: "bootstrap"
    },
        f = {
            o: 1,
            b: 2,
            high: 3
        },
        w = {
            j: 1,
            w: 2
        },
        L = {
            small: "[0em,40em]",
            b: "[40.063em,64em]",
            B: "[64.063em,inf]"
        },
        M = {
            H: "[0,543]",
            F: "[544,767]",
            D: "[768,991]",
            C: "[992,1199]",
            G: "[1200,inf]"
        };
    d(function() {
        z()
    })
})("undefined" == typeof jQuery ? null : jQuery);
